import React from 'react';

const Start = () => {
  return (
    <div className="flex">
      <button className="btn">Button</button>
      <button className="btn btn-outline">Default</button>
      <button className="btn btn-outline btn-primary">Primary</button>
      <button className="btn btn-outline btn-secondary">Secondary</button>
      <button className="btn btn-outline btn-accent">Accent</button>
    </div>
  );
};

export default Start;
