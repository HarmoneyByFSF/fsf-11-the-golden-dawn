import React, { useEffect, useState, useContext } from 'react';
import { WeekdayEnum, MonthEnum, getDaysInMonth } from './utils/timeUtils';

// Configuration
const secondsToDay = 1; // Number of real-world seconds equivalent to a day in the game
const yearOffset = 0; // Offset to the current real-time year

const GameClockContext = React.createContext({
    gameTime: {
        hoursElapsed: 0,
        currentDayOfTheWeek: WeekdayEnum.Monday,
        currentDayOfTheMonth: 1,
        currentMonthOfTheYear: MonthEnum.January,
        currentYear: 0,
        daysElapsed: 0,
        weeksElapsed: 0,
        monthsElapsed: 0,
        yearsElapsed: 0,
        weekdayName: '',
        monthName: '',
    },
    pause: () => {},
    resume: () => {},
    addDailyEvent: () => {},
    addWeeklyEvent: () => {},
    addMonthlyEvent: () => {},
    addYearlyEvent: () => {},
});

const GameClockProvider = ({ children }) => {
    const [gameTime, setGameTime] = useState({
        hoursElapsed: 0,
        currentDayOfTheWeek: WeekdayEnum.Monday,
        currentDayOfTheMonth: 1,
        currentMonthOfTheYear: MonthEnum.January,
        currentYear: 0,
        daysElapsed: 0,
        weeksElapsed: 0,
        monthsElapsed: 0,
        yearsElapsed: 0,
        weekdayName: '',
        monthName: '',
    });

    const [isPaused, setIsPaused] = useState(false);
    const [dailyEvents, setDailyEvents] = useState([]);
    const [weeklyEvents, setWeeklyEvents] = useState([]);
    const [monthlyEvents, setMonthlyEvents] = useState([]);
    const [yearlyEvents, setYearlyEvents] = useState([]);

    useEffect(() => {
        const millisecondsPerDay = 1000 * secondsToDay;
        const startTime = new Date().getTime();
        let interval;

        const updateGameTime = () => {
            if (!isPaused) {
                const currentTimestamp = new Date().getTime();
                const elapsedMilliseconds = currentTimestamp - startTime;

                // Calculate game date and time
                const elapsedDays = Math.floor(elapsedMilliseconds / millisecondsPerDay);
                const elapsedWeeks = Math.floor(elapsedDays / 7);
                const elapsedMonths = Math.floor(elapsedDays / getDaysInMonth(gameTime.currentMonthOfTheYear));
                const elapsedYears = Math.floor(elapsedMonths / 12);

                const currentDayOfTheWeek = (gameTime.currentDayOfTheWeek + elapsedDays) % 7 || 7;
                const currentDayOfTheMonth = (gameTime.currentDayOfTheMonth + elapsedDays) % (getDaysInMonth(gameTime.currentMonthOfTheYear) + 1) || getDaysInMonth(gameTime.currentMonthOfTheYear);
                const currentMonthOfTheYear = (gameTime.currentMonthOfTheYear + elapsedMonths) % 13 || 12;
                const currentYear = gameTime.currentYear + elapsedYears;

                // Check if month or year has changed
                if (currentMonthOfTheYear !== gameTime.currentMonthOfTheYear) {
                    // Trigger monthly events
                    monthlyEvents.forEach(event => event.callback());
                }
                if (currentYear !== gameTime.currentYear) {
                    // Trigger yearly events
                    yearlyEvents.forEach(event => event.callback());
                }

                // Update gameTime object
                setGameTime(prevGameTime => ({
                    ...prevGameTime,
                    hoursElapsed: Math.floor((elapsedMilliseconds % millisecondsPerDay) / 1000 / 60 / 60),
                    currentDayOfTheWeek,
                    currentDayOfTheMonth,
                    currentMonthOfTheYear,
                    currentYear,
                    daysElapsed: elapsedDays,
                    weeksElapsed: elapsedWeeks,
                    monthsElapsed: elapsedMonths,
                    yearsElapsed: elapsedYears,
                    weekdayName: WeekdayEnum[currentDayOfTheWeek],
                    monthName: MonthEnum[currentMonthOfTheYear],
                }));

                // Trigger daily events
                dailyEvents.forEach(event => event.callback());
            }
        };

        // Update game time initially and then every second
        updateGameTime();
        interval = setInterval(updateGameTime, 1000);

        // Clean up the interval on component unmount
        return () => {
            clearInterval(interval);
        };
    }, [isPaused, dailyEvents, weeklyEvents, monthlyEvents, yearlyEvents]);

    const pause = () => {
        setIsPaused(true);
    };

    const resume = () => {
        setIsPaused(false);
    };

    const addDailyEvent = (name, callback) => {
        setDailyEvents([...dailyEvents, { name, callback }]);
    };

    const addWeeklyEvent = (name, callback) => {
        setWeeklyEvents([...weeklyEvents, { name, callback }]);
    };

    const addMonthlyEvent = (name, callback) => {
        setMonthlyEvents([...monthlyEvents, { name, callback }]);
    };

    const addYearlyEvent = (name, callback) => {
        setYearlyEvents([...yearlyEvents, { name, callback }]);
    };

    return (
      <GameClockContext.Provider
        value={{
            gameTime,
            pause,
            resume,
            addDailyEvent,
            addWeeklyEvent,
            addMonthlyEvent,
            addYearlyEvent,
        }}
      >
          {children}
      </GameClockContext.Provider>
    );
};

const GameTimeDisplay = () => {
    const { gameTime, pause, resume } = useContext(GameClockContext);

    return (
      <div>
          <p>Day of the Week: {gameTime.currentDayOfTheWeek}</p>
          <p>Day of the Month: {gameTime.currentDayOfTheMonth}</p>
          <p>Month of the Year: {gameTime.currentMonthOfTheYear}</p>
          <p>Current Year: {gameTime.currentYear}</p>
          <p>Elapsed Days: {gameTime.daysElapsed}</p>
          <p>Elapsed Weeks: {gameTime.weeksElapsed}</p>
          <p>Elapsed Months: {gameTime.monthsElapsed}</p>
          <p>Elapsed Years: {gameTime.yearsElapsed}</p>
          <p>Weekday Name: {gameTime.weekdayName}</p>
          <p>Month Name: {gameTime.monthName}</p>
          <button onClick={pause}>Pause</button>
          <button onClick={resume}>Resume</button>
      </div>
    );
};

export { GameClockProvider, GameTimeDisplay, GameClockContext };
