import React from 'react';
import { GameClockProvider, GameTimeDisplay } from './GameClock';
import MyComponent from './MyComponent';
import CustomComponent from './CustomComponent';
import CustomComponent1 from './CustomComponent1';
import Start from "./pages/Start";

import './App.css';

const App = () => {
  return (
      <GameClockProvider>
        <Start />
        {/*<GameTimeDisplay />*/}
        {/*<MyComponent />*/}
        {/*<CustomComponent />*/}
        {/*<CustomComponent1 />*/}
      </GameClockProvider>
  );
};

export default App;
